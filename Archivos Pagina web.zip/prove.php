<?php

	session_start();
	require 'conexion.php';

	if(!isset($_SESSION["id_usuario"])){
		header("Location: index.php");
	}

	$idUsuario = $_SESSION['id_usuario'];
	$tipo_usuario = $_SESSION['tipo_usuario'];

	if($tipo_usuario == 1){
		$where = "";
		} else if($tipo_usuario == 2){
			$where = "WHERE id=$idUsuario";
	}

	$sql = "SELECT * FROM usuarios $where";
	$resultado = $mysqli->query($sql);



	$sql = "SELECT * FROM usuarios $where";
	$resultado = $mysqli->query($sql);

 

?>

<!DOCTYPE HTML>
<html>
	<head>
    <title>TELEBIOM</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <link rel="stylesheet" href="assets/css/main.css" />
    
  </head>

  <body class="is-preload">

    <!-- Header -->
      <header id="header">
        <img src="images/logo.png" width="43" height="43" />  
        <a class="logo" href="welcome.php">TELEBIOM</a>
        <nav>
          <?php echo ($row['nombre']); ?>
          <a href="#menu">Menu</a>
        </nav>
      </header>

    <!-- Nav -->
      <nav id="menu">
        <ul class="links">
          <li class="nav-item"><a class="nav-link active" href="welcome.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="generic.php">Cuenta</a></li>
          <li class="nav-item"><a class="nav-link" href="salir.php">Salir</a></li>
        </ul>
      </nav>

		<!-- Heading -->
			<div id="heading" >
				<h1>Generic Page</h1>
			</div>

		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="inner">
					<div class="content">
						<header>
							<h2>Feugiat consequat</h2>
						</header>
						<p>Lorem ipsum dolor sit accumsan interdum nisi, quis tincidunt felis sagittis eget. tempus euismod. Magna et cursus lorem faucibus vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing accumsan eu faucibus. Integer ac pellentesque praesent tincidunt felis sagittis eget. tempus euismod tempus. Vestibulum ante ipsum primis in faucibus vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing accumsan eu faucibus. Integer ac pellentesque praesent tincidunt felis sagittis eget. tempus euismod. Vestibulum ante ipsum primis in faucibus vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing accumsan eu faucibus. Integer ac sed amet praesent. Nunc lacinia ante nunc ac gravida lorem ipsum dolor sit amet dolor feugiat consequat. </p>
					</div>
				</div>
				<div class="inner">
					<div class="content">
						<header>
							<h2>Subir archivos</h2>
						</header>
				<!-- Elements -->
				<div class="row">
					<div class="col-10 col-12-medium">
					<!-- Table -->
						<div class="table-wrapper">
							<table>
								<thead>
									<tr>
										<th><i>Usuario</i></th>
										<th><i>Nombre</i></th>
										<th><i>Tipo Usuario</i></th>
										<th><i>Archivos</i></th>
										<th><i>Otro</i></th>
									</tr>
								</thead>
								<tbody>
									<?php while($row = $resultado->fetch_assoc()) { ?>

										<tr>
											<td><?php echo $row['usuario']; ?></td>
											<td><?php echo $row['nombre']; ?></td>
											<td><?php echo $row['correo']; ?></td>
											<?php if($row['mostrar']==1){?>
											<td><a href="prove.php" style="color: red; font-size:18px;"><span class="icon fa-pencil" aria-hidden="true"></span> </a></td>
											<?php } ?>
											<td><?php echo $row['mostrar']; ?></td>
										</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
					</div>
				</div>

		<!-- Footer -->
		<footer id="footer">
			<div class="inner">
				<div class="content">
					<section>
						<h4>Redes Sociales</h4>
						<ul class="icons">
							<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
							<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
							<li><a href="#" class="icon fa-linkedin"><span class="label">linkedIn</span></a></li>
							<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
						</ul>
					</section>
				</div>
				<div class="copyright">
					&copy; Untitled. 
				</div>
			</div>
		</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>
