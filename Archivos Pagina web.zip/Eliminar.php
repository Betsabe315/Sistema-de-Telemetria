<?php
session_start();
session_destroy();
  require 'conexion.php';
  include 'config.php';

  if(!isset($_SESSION["id_usuario"])){
    header("Location: index.php");
  }

  $idUsuario = $_SESSION['id_usuario'];
  $tipo_usuario = $_SESSION['tipo_usuario'];

  if($tipo_usuario == 1){
    $where = "";
    } else if($tipo_usuario == 2){
      $where = "WHERE id=$idUsuario";
  }

  $stmt = Conexion::conectar()->prepare("DELETE FROM usuarios $where");
  $stmt->execute();

// Redirigiendo hacia atrás
header("Location: " . "welcome.php")
?>