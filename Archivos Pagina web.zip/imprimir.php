<?php
$conexion=mysqli_connect("localhost","root",""); mysqli_select_db($conexion, "login");
$resultado=mysqli_query($conexion, "select * from archivos");
?>
	<table border="2" bordercolor="blue">
	<tr>
		<td>####</td>
		<td>FECHA</td>
		<td>DISPONIBLE</td>
	</tr>
		<?php
		$i=0;
		while ($fila = mysqli_fetch_array($resultado)){
		 echo "<tr><td>".$i."</td><td>".$fila['name']."</td><td>".$fila['description']."</td></tr>"; $i++;
		}
		mysqli_close($conexion);
		?>
</table>
