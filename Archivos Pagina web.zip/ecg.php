<?php

	session_start();

?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Generic Page - Industrious by TEMPLATED</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link rel="stylesheet" href="assets/css/main.css" />
		
	</head>

	<body class="is-preload">

		<!-- Header -->
			<header id="header">
				<a class="logo" href="welcome.php">TELEBIOM</a>
				<nav>
					<a href="#menu">Menu</a>
				</nav>
			</header>

		<!-- Nav -->
			<nav id="menu">
				<ul class="links">
					<li><a href="principal.php">Home</a></li>
					<li class="nav-item"><a class="nav-link" href="registro.php">Registro</a></li>
					<li class="nav-item"><a class="nav-link" href="index.php">Ingreso</a></li>
				</ul>
			</nav>

		<!-- Heading -->
			<div id="heading" >
				<h1>Electrocardiograma (ECG)</h1>
			</div>

		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="inner">
					<div class="content">
						<header>
							<h3><b>¿Qué es un electrocardiograma?</b></h3>
						</header>
						<dl>
							<dt>Biopotenciales</dt>
							<dd>
								<p>Los biopotenciales son señales que se generan debido a la actividad electroquímica de células excitables, dicha actividad eléctrica se produce por medio del intercambio de iones en la membrana celular, lo que genera una diferencia de potencial produciendo, así, un estímulo en diferentes partes del cuerpo, por ejemplo en el cerebro, corazón y músculos.</p>
								<center><img src="images/biopot.jpg" alt="Pic 02"width="40%" height="40%">
								<p>1. Obtenido de: <a href="https://bibdigital.epn.edu.ec/bitstream/15000/19883/1/CD-9300.pdf">https://bibdigital.epn.edu.ec/bitstream/15000/19883/1/CD-9300.pdf</a></p></center>

							</dd>
							<dt>Electrocardiograma (ECG)</dt>
							<dd>
								<p>El corazón contiene células miocárdicas especiales llamadas células marcapasos, las cuales generan potenciales de acción rítmica espontáneos para controlar el corazón, provocando que el resto de las células del miocardio del corazón se contraigan en un patrón específico (aurículas primero, pasa un tiempo, y ventrículos). Un electrocardiógrafo consiste en un sistema que registra la actividad eléctrica o biopontencial del corazón, dicho sistema es importante en la vida diaria debido a que nos permite la observación con fines diagnósticos o terapéuticos de la actividad vital del individuo.</p>
								<p>De manera que los biopotenciales generados por los impulsos eléctricos del corazón van a poder ser medidos a través del uso del electrocardiograma, también llamado ECG, el cual es una representación gráfica de dichos impulsos generados por el corazón; es a través de la señal obtenida por ECG que se puede saber si se posee algún tipo de enfermedad o si el paciente se encuentra sano y esto se puede saber al observar la onda P, la onda T y los complejos Q,R,S, mostrados en dicho estudio.</p>
								<center><img src="images/ecg.png" alt="Pic 02"width="40%" height="40%">
								<p>1. Obtenido de: <a href="https://www.iberomed.es/blog/2018/03/02/electrocardiograma-o-ecg-preguntas-frecuentes/">Iberomed</a></p></center>
								<p>Las contracciones rítmicas del corazón están controladas por una serie ordenada de descargas eléctricas. Antes de cada contracción del músculo cardáaco se genera un impulso eléctrico por despolarización en el nodo sino auricular, es decir, la activacióon eléctrica del corazón que se produce por modificación de la polaridad de la membrana celular al ingresar el sodio, esta se propaga concéntricamente produciendo la onda P, mientras que la despolarización ventricular es la que determina la onda QRS del ECG.</p>
								<p>Por otro lado, la repolarización es la que va a llevar a cabo la recuperación de la polaridad; la repolarización  auricular queda oculta en la onda QRS y la repolarizaciónventricular se refleja en el segmento ST y en la onda T (una onda lenta). </p>
								<p>La onda cardíaca obtenida corresponde a un tono puro de 3.33 Hz para 200 pulsaciones por minuto (actividad física intensa) y uno de 1 - 1,25 Hz para 60 - 75 pulsaciones por minuto (estado de reposo), asímismo la onda dista bastante de una senoidal pura, teniendo la mayor parte de la información entre los 0 y 40 Hz. </p>
							</dd>
							<dt>Electrodo de bipotencial</dt>
							<dd>
								<p>Para poder medir los biopotenciales producidos por el corazón se utilizan electrodos, los cuales son un conductor eléctrico utilizado para hacer contacto con una parte no metálica de un circuito, realizan la transducción de corrientes iónicas en el cuerpo a electrónicas en el sistema de medición.</p>
								<p>El funcionamiento de los electrodos será, principalmente que, al poner en contacto el electrodo con la piel (disolución electrolítica), se dará un intercambio iónico entre el conductor metálico y la disolución.</p>
								<p>Los electrodos que se utilizan para el ECG son electrodos de superficie, compuestos por un electrodo de metal y se unen a la superficie del cuerpo mediante un gel electrolítico o electrolito.</p>
								<center><img src="images/electrodos.jpg" alt="Pic 02"width="40%" height="40%">
								<p>1. Obtenido de: <a href="http://metron-ms.com/productos/electrodos/electrodos-ecg/">METRON Medical Supplies</a></p></center>
							</dd>
							<dt>Frecuencia cardíaca</dt>
							<dd>
								<p>La frecuencia o ritmo cardiaco es el periodo armónico de latidos del corazón, conformados por la contracción (sístole) del órgano para impulsar sangre y su relajación (diástole), que permite se llene de sangre nuevamente. Este proceso genera "ruidos", conocidos como sonidos de Korotkoff en honor a su descubridor. Si estos ruidos no se presentan de forma periódica, el corazón está presentando una arritmia; es decir que presenta una variación en su ritmo normal, lo cual puede provocar que palpite de forma irregular, ya sea demasiado lento o rápido.</p> 
								<p>De esta forma es que se define a la frecuencia cardiaca como los ciclos de llenado y vaciado de sangre de las cámaras en un determinado tiempo, y que esta dada en latidos por minuto, donde su parámetro normal es de 60 a 100 lpm.</p> 
								<p>Esta se puede medir manualmente en diversas arterias del cuerpo en el pulso periférico (radial, temporal, carotídeo, humeral, cubital, femoral, poplíteo, tibial posterior y pedio). También se puede medir colocando el fonendoscopio sobre el quinto espacio intercostal izquierdo, además se pueden ocupar monitores de frecuencia cardiaca en caso de ser necesario.</p>
							</dd>
						</dl>
					</div>
				</div>

		<div class="inner">
          	<div class="content">
          	<ul class="actions fit">
            	<li></li>
              	<li><a href="principal.php" class="button primary fit small">Página principal</a></li>
              	<li></li>
            </ul>
          	</div>
        </div>
      </section>
				  
				
		<!-- Footer -->
		<footer id="footer">
				<div class="inner">
					<div class="content">
						<script src="https://kit.fontawesome.com/e7f1b73dfb.js" crossorigin="anonymous"></script>
						<section>
							<h4>Redes Sociales</h4>
							<ul class="icons">
								<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
								<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
								<li><a href="#" class="icon fa-linkedin"><span class="label">linkedIn</span></a></li>
								<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
							</ul>
						</section>
					</div>
					<div class="copyright">
						&copy; Untitled. 
					</div>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>