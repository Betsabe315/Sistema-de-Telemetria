<?php

	require 'conexion.php';
	require 'funcs/funcs.php';

	$errors = array();

	if(!empty($_POST)){

		$email = $mysqli->real_escape_string($_POST['email']);

		if(!isEmail($email)){

			$errors[] = "Ingrese un correo electrónico válido";

			if(emailExiste($email)){

				$user_id = getValor('id', 'correo', $email);
				$nombre = getValor('nombre', 'correo', $email);

				$token = generaTokenPass($email);

				$url = 'http://'.$_SERVER["SERVER_NAME"].'/login/cambia_pass.php?user_id='.$user_id.'&token='.$token;

				$asunto = 'Recuperar Password - TELEBIOM';
				$cuerpo = "Hola $nombre: <br /><br />Se ha solicitafo un reinicio de contrase&ntilde;a, ingresa a la siguiente direcci&oacute;n: <a href='$url'>$url</a>";

				if(enviarEmail($email, $nombre, $asunto, $cuerpo)){

					echo "Hemos enviado un correo electrónico a la dirección $email para reestablecer tu contraseña.<br />";;
					echo "<a href='index.php'>Iniciar Sesión</a>";
					exit;

				}else{

					$errors[] = "Error al enviar el Email";
				}

			}else{

				$errors[] = "No existe el correo electrónico";
			}
		}
	}

?>

<!DOCTYPE HTML>
<html lang="en">
	<head>
		<title>Recuperar contraseña</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">

		<!-- Header -->
			<header id="header">
				<img src="images/logo.png" width="43" height="43" />  
				<a class="logo" href="principal.php">TELEBIOM</a>
				<nav>
					<a href="#menu">Menu</a>
				</nav>
			</header>

		<!-- Nav -->
			<nav id="menu">
				<ul class="links">
					<li><a href="principal.php">Home</a></li>
					<li class="nav-item"><a class="nav-link" href="registro.php">Registro</a></li>
					<li class="nav-item"><a class="nav-link" href="index.php">Ingreso</a></li>
				</ul>
			</nav>

		<!-- Heading -->
			<div id="heading" >
				<h1>Recuperar contraseña</h1>
			</div>

		<!--=====================================
		CONTENIDO
		======================================-->
		<div class="inner">
			<div class="row gtr-uniform">
				<div class="col-lg-7">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
						<form id="loginform" class="form-horizontal" role="form" method="POST" action="<?php $_SERVER['PHP_SELF'] ?>" autocomplete="off">
							<div class="container-fluid">
								<p><div class="col-8">		
									<label for="email">Correo electrónico:</label></div></p>
									<input type="email" class="form-control" placeholder="Correo electrónico" id="email" name="email" required>
								<p></p>	
		                        <div class="text-center">
		                            <p><button type="submit" class="button primary">Enviar</button></p>
		                        </div>
		                        <p></p>
		                        <div class="text-center">
		                            <a class="small" href="registro.html">No tiene una cuenta? Crear cuenta</a>
		                        </div>
		                    </div>
						</form>
						<?php echo resultBlock($errors); ?>
					</div>
				</div>
			</div>
		</div>

		<!-- Footer -->
			<footer id="footer">
				<div class="inner">
					<div class="content">
						<section>
							<h4>Redes Sociales</h4>
							<ul class="icons">
								<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
								<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
								<li><a href="#" class="icon fa-linkedin"><span class="label">linkedIn</span></a></li>
								<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
							</ul>
						</section>
					</div>
					<div class="copyright">
						&copy; Untitled. 
					</div>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>