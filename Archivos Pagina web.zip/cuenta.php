<?php
session_start();
  require 'conexion.php';
  include 'config.php';

  if(!isset($_SESSION["id_usuario"])){
    header("Location: index.php");
  }

  $idUsuario = $_SESSION['id_usuario'];
  $tipo_usuario = $_SESSION['tipo_usuario'];

  if($tipo_usuario == 1){
    $where = "";
    } else if($tipo_usuario == 2){
      $where = "WHERE id=$idUsuario";
  }

  $sql = "SELECT * FROM usuarios $where";
  $resultado = $mysqli->query($sql);
  //echo $row['activacion'];

  
 ?> 
<!DOCTYPE HTML>
<html>
  <head>
    <title>TELEBIOM</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <link rel="stylesheet" href="assets/css/main.css" />
    
  </head>

  <body class="is-preload">

    <!-- Header -->
      <header id="header">
        <img src="images/logo.png" width="43" height="43" />  
        <a class="logo" href="welcome.php">TELEBIOM</a>
        <nav>
          <a href="#menu">Menu</a>
        </nav>
      </header>

    <!-- Nav -->
      <nav id="menu">
        <ul class="links">
          <li class="nav-item"><a class="nav-link active" href="welcome.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="generic.php">Cuenta</a></li>
          <li class="nav-item"><a class="nav-link" href="salir.php">Salir</a></li>
        </ul>
      </nav>


    <!-- Heading -->
      <div id="heading" >
        <h1>Información de la cuenta</h1>
      </div>

    <!-- Main -->
      <section id="main" class="wrapper">
        <div class="inner">
          <div class="content">
            <p>En este apartado podrás encontar la información de tu cuenta, así como editarla.</p>
          </div>
        </div>
        <div class="inner">
        	<div class="content">
	            <header>
	              <h2>Información de la cuenta</h2>
	            </header>
	            <div class="table-wrapper">
					<table>
						<?php while($row = $resultado->fetch_assoc()) { ?>
						<thead>
								<tr>
			                      <th width="50%"><i>Nombre de usuario</i></th>
			                      <th width="50%"><i>Correo electrónico</i></th>
			                    </tr>
						</thead>
						<tbody>

								<tr>
									<td><?php echo $row['nombre']; ?></td>
									<td><?php echo $row['correo']; ?></td>						
								</tr>
						</tbody>
						<?php } ?>
					</table>
				</div>
			</div>
		</div>

        <div class="inner">
        	<div class="content">
          		<header>
          		<h2>Editar cuenta</h2>
        		</header>
	            <form action="success.php" method="post" enctype="multipart/form-data">
	            <br><br> Nombre: <input name="nombreedit" type="text" placeholder="Coloque el nombre del usuario" size="70" maxlength="70"> 
	            <br><br> Correo electrónico: <input name="emailedit" type="text" placeholder="Coloque su nuevo correo electrónico" size="70" maxlength="70">
	            <br><br> 
	            <input class="button primary" name="submit" type="submit" value="Editar cuenta">   
	            </form>
          	</div>
        </div>

        <div class="inner">
          <div class="content">
            <ul class="actions fit">
              <li><a href="generic.php" class="button primary fit">Regresar</a></li>
              <li></li>
              <li><a href="Eliminar.php" class="button primary fit" onclick="return confirm('Esta seguro de eliminar la cuenta?');">Eliminar cuenta</a></li>
            </ul>
            <ul class="actions fit"><li></li></ul>
            <ul class="actions fit"><li></li></ul>
            <ul class="actions fit">
              <li></li>
              <li><a href="welcome.php" class="button fit small">Página principal</a></li>
              <li></li>
            </ul>
          </div>
        </div>
                
    <!-- Footer -->
    <footer id="footer">
        <div class="inner">
          <div class="content">
            <script src="https://kit.fontawesome.com/e7f1b73dfb.js" crossorigin="anonymous"></script>
            <section>
              <h4>Redes Sociales</h4>
              <ul class="icons">
                <li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
                <li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
                <li><a href="#" class="icon fa-linkedin"><span class="label">linkedIn</span></a></li>
                <li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
              </ul>
            </section>
          </div>
          <div class="copyright">
            &copy; Untitled. 
          </div>
        </div>
      </footer>

    <!-- Scripts -->
      <script src="assets/js/jquery.min.js"></script>
      <script src="assets/js/browser.min.js"></script>
      <script src="assets/js/breakpoints.min.js"></script>
      <script src="assets/js/util.js"></script>
      <script src="assets/js/main.js"></script>

  </body>
</html>