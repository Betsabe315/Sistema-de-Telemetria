<?php

  session_start();
  require 'conexion.php';

  if(!isset($_SESSION["id_usuario"])){
    header("Location: index.php");
  }

  $idUsuario = $_SESSION['id_usuario'];
  $tipo_usuario = $_SESSION['tipo_usuario'];

  if($tipo_usuario == 1){
    $where = "";
    } else if($tipo_usuario == 2){
      $where = "WHERE id=$idUsuario";
  }

  $sql = "SELECT * FROM usuarios $where";
  $resultado = $mysqli->query($sql);

?>

<!DOCTYPE HTML>
<html>
  <head>
    <title>TELEBIOM</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <link rel="stylesheet" href="assets/css/main.css" />
    
  </head>

  <body class="is-preload">

    <!-- Header -->
      <header id="header">
        <img src="images/logo.png" width="43" height="43" />  
        <a class="logo" href="welcome.php">TELEBIOM</a>
        <nav>
          <a href="#menu">Menu</a>
        </nav>
      </header>

    <!-- Nav -->
      <nav id="menu">
        <ul class="links">
          <li class="nav-item"><a class="nav-link active" href="welcome.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="generic.php">Cuenta</a></li>
          <li class="nav-item"><a class="nav-link" href="salir.php">Salir</a></li>
        </ul>
      </nav>

    <!-- Heading -->
      <div id="heading" >
        <h1>Archivos</h1>
      </div>

    <!-- Main -->
      <section id="main" class="wrapper">
        <div class="inner">
          <div class="content">
            <p>En este apartado podrás encontrar tus archivos disponibles, asímismo podras configurar los archivos, ya sea, cambiarlos o eliminarlos.</p>
          </div>
        </div>
        <div class="inner">
          <div class="content">
            <header>
              <h2>Archivos disponibles</h2>
            </header>
            <ul class="actions fit"><li></li></ul>
            <ul class="actions fit"><li></li></ul>
        <!-- Elements -->
          <div class="row">
            <div class="col-10 col-12-medium">
            <!-- Table -->
              <div class="table-wrapper">
                <table>
                  <thead>
                    <?php while($row = $resultado->fetch_assoc()) { ?>
                    <?php
                    $arc=$row['ruta'];
                    $del = substr($arc, 1);
                    //echo $del;
                    $rutalen = strlen($del)-1;
                    //echo $rutalen;
                    $documento = substr($del, 0, $rutalen);
                    //echo $documento;
                    //obtiene el nombre del archivo a descargar pasado por 'url'
                    $directorio = 'upload/';
                    $ficheros1  = scandir($directorio);
                    //var_export ($ficheros1);
                    $indice = array_search($documento,$ficheros1,false);
                    //echo "El número 5 está en el indice: " . $indice;
                    ?>
                    <tr>
                      <th width="10%"><i>Usuario</i></th>
                      <?php if($row['mostrar']==0){?>
                        <th width="20%"><i>Nombre del Archivo</i></th>
                        <th width="60%"><i>Descripción</i></th>
                        <th width="10%"><i>Subir Archivo</i></th>
                      <?php }else{?>
                        <th width="40%"><i>Nombre del Archivo</i></th>
                        <th width="36%"><i>Descripción</i></th>
                        <th width="7%"><i>Descargar</i></th>
                        <th width="7%"><i>Eliminar</i></th>
                        <th width="7%"><i>Editar</i></th>
                      <?php } ?>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      $archivos = scandir("upload");
                      $num=0;
                    ?>
                    <tr>
                      <td><?php echo $row['usuario']; ?></td>
                      <?php if($row['mostrar']==0){?>
                        <td><?php echo "*****"; ?></td>
                        <td><?php echo "No hay archivos disponibles"; ?></td>
                        <td><a href="archivos.php" style="color: red; font-size:18px;"><span class="icon fa-pencil" aria-hidden="true"></span> </a></td>
                      <?php }else{?>
                        <td><?php echo $row['ruta']; ?></td>
                        <td><?php echo $row['description']; ?></td>
                        <td><a title="Descargar Archivo" href="upload/<?php echo $archivos[$indice]; ?>" download="<?php echo $archivos[$indice]; ?>" style="color: black; font-size:18px;"> <span class="icon fa-download" aria-hidden="true"></span> </a></td>
                        
                        <td><a title="Eliminar Archivo" href="delete.php" style="color: red; font-size:18px;" onclick="return confirm('Esta seguro de eliminar el archivo?');"> <span class="icon fa-trash" aria-hidden="true"></span> </a></td>
                        <td><a href="archivos.php" style="color: blue; font-size:18px;"><span class="icon fa-pencil" aria-hidden="true"></span> </a></td>
                      <?php } ?>
                    <?php } ?>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          </div>
        </div>
        <div class="inner">
          <div class="content">
            <ul class="actions fit">
              <li></li>
              <li><a href="generic.php" class="button primary fit">Regresar</a></li>
              <li></li>
            </ul>
            <ul class="actions fit"><li></li></ul>
            <ul class="actions fit"><li></li></ul>
            <ul class="actions fit">
              <li></li>
              <li><a href="welcome.php" class="button fit small">Página principal</a></li>
              <li></li>
            </ul>
          </div>
        </div>
      </section>

 
    <!-- Footer -->
    <footer id="footer">
        <div class="inner">
          <div class="content">
            <script src="https://kit.fontawesome.com/e7f1b73dfb.js" crossorigin="anonymous"></script>
            <section>
              <h4>Redes Sociales</h4>
              <ul class="icons">
                <li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
                <li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
                <li><a href="#" class="icon fa-linkedin"><span class="label">linkedIn</span></a></li>
                <li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
              </ul>
            </section>
          </div>
          <div class="copyright">
            &copy; Untitled. 
          </div>
        </div>
      </footer>

    <!-- Scripts -->
      <script src="assets/js/jquery.min.js"></script>
      <script src="assets/js/browser.min.js"></script>
      <script src="assets/js/breakpoints.min.js"></script>
      <script src="assets/js/util.js"></script>
      <script src="assets/js/main.js"></script>

  </body>
</html>