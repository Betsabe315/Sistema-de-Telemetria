<?php
	session_start();
	require 'conexion.php';
	require 'funcs/funcs.php';

	if(!isset($_SESSION["id_usuario"])){
		header("Location: index.php");
	}

	$idUsuario = $_SESSION['id_usuario'];
	$tipo_usuario = $_SESSION['tipo_usuario'];

	$sql = "SELECT id, nombre FROM usuarios WHERE id = '$idUsuario'";
	$result = $mysqli->query($sql);

	$row = $result->fetch_assoc();

?>

<!DOCTYPE HTML>
<!--
	Industrious by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>TELEBIOM</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">

		<!-- Header -->
			<header id="header">
				<img src="images/logo.png" width="43" height="43" />  
				<a class="logo" href="welcome.php">TELEBIOM</a>
				<nav>
					<?php echo ($row['nombre']); ?>
					<a href="#menu">Menu</a>
				</nav>
			</header>

		<!-- Nav -->
			<nav id="menu">
				<ul class="links">
					<li class="nav-item"><a class="nav-link active" href="welcome.php">Home</a></li>
					<?php if($tipo_usuario == 1) { ; ?>
					<li class="nav-item"><a class="nav-link" href="todos.php">TODOS</a></li>
					<?php } ; ?>
					<li class="nav-item"><a class="nav-link" href="generic.php">Cuenta</a></li>
					<li class="nav-item"><a class="nav-link" href="salir.php">Salir</a></li>
					

				</ul>
			</nav>

		<!-- Banner -->

			<section id="banner">
				<div class="inner">
					
					<img src="images/logo.png" width="140" height="140" />
					<h1>TELEBIOM UNAM</h1>
					<h3><i>Telemedicina cardiológica</i></h3>
		
				</div>	
				<video autoplay loop muted playsinline src="images/ecg.mp4"></video>

			</section>

		<!-- Highlights -->
			<section class="wrapper">
				<div class="inner">
					<header class="special">
						<p>Si desea mas información, oprima el icono de interés </p>
					</header>
					<div class="highlights">
						<section>
							<div class="content">
								<header>
									<script src="https://kit.fontawesome.com/e7f1b73dfb.js" crossorigin="anonymous"></script>
									<a href="telebiom.php" class="icon fa-address-card"><span class="label">Icon</span></a>
									<h3><b>Que es Telebiom UNAM?</b></h3>
								</header>
								<p>TELEBIOM UNAM es una página enfocada a la Telemedicina cardiológica.</p>
							</div>
						</section>
						<section>
							<div class="content">
								<header>
									<script src="https://kit.fontawesome.com/e7f1b73dfb.js" crossorigin="anonymous"></script>
									<a href="telebiom.php" class="icon fa-laptop-medical"><span class="label">Icon</span></a>
									<h3><b>Nuestro objetivo</b></h3>
								</header>
								<p>TELEBIOM UNAM es un apoyo para médicos, que brinda una mejor accesibilidad a estudios cardiológicos.</p>
							</div>
						</section>
						<section>
							<div class="content">
								<header>
									<script src="https://kit.fontawesome.com/e7f1b73dfb.js" crossorigin="anonymous"></script>
									<a href="ecg.php" class="icon fa-heartbeat"><span class="label">Icon</span></a>
									<h3><b>QUE ES UN ECG?</b></h3>
								</header>
								<p>Un Electrocardiograma (ECG), es una representación gráfica de los impulsos generados por el corazón.</p>
							</div>
						</section>
						<section>
							<div class="content">
								<header>
									<script src="https://kit.fontawesome.com/e7f1b73dfb.js" crossorigin="anonymous"></script>
									<a href="#" class="icon fa-tools"><span class="label">Icon</span></a>
									<h3><b>Como se desarrollo?</b></h3>
								</header>
								<p>En este apartado puede conocer mejor como se llevó a cabo este proyecto y conocer a detalle sus componentes.</p>
							</div>
						</section>
						<section>
							<div class="content">
								<header>
									<script src="https://kit.fontawesome.com/e7f1b73dfb.js" crossorigin="anonymous"></script>
									<a href="registro.php" class="icon fa-file-medical-alt"><span class="label">Icon</span></a>
									<h3><b>Crea tu cuenta</b></h3>
								</header>
								<p>Si eres un paciente puedes crear tu cuenta y comenzar a guardar tu información médica.</p>
							</div>
						</section>
						<section>
							<div class="content">
								<header>
									<script src="https://kit.fontawesome.com/e7f1b73dfb.js" crossorigin="anonymous"></script>
									<a href="index.php" class="icon fa-key"><span class="label">Icon</span></a>
									<h3><b>Ingresa al sistema</b></h3>
								</header>
								<p>Si ya tienes tu cuenta, ingresa al sistema.</p>
							</div>
						</section>
					</div>
				</div>
			</section>

		<!-- Testimonials -->
			<section id="cta" class="wrapper">
				<div class="inner">
					<header class="special">
						<h2>Creadores</h2>
					
				</div>
			</section>

				<section>
					
						
					<div class="testimonials">
						<section>
							<div class="content">
								<div class="author">
									<div class="image">
										<img src="images/icono.png" alt="" />
									</div>
									<p class="credit">- <strong>Jimena Ciros</strong> <span>UNAM Facultad de Ciencias</span></p>
								</div>
							</div>
						</section>
						<section>
							<div class="content">
								<div class="author">
									
								</div>
							</div>
						</section>
						<section>
							<div class="content">
								<div class="author">
									<div class="image">
										<img src="images/icono.png" alt="" />
									</div>
									<p class="credit">- <strong>Betsabé Santos</strong> <span>UNAM Facultad de Ciencias</span></p>
								</div>
							</div>
						</section>
					</div>
				</section>

		<!-- Footer -->
		<footer id="footer">
				<div class="inner">
					<div class="content">
						<script src="https://kit.fontawesome.com/e7f1b73dfb.js" crossorigin="anonymous"></script>
						<section>
							<h4>Redes Sociales</h4>
							<ul class="icons">
								<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
								<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
								<li><a href="#" class="icon fa-linkedin"><span class="label">linkedIn</span></a></li>
								<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
							</ul>
						</section>
					</div>
					<div class="copyright">
						&copy; Untitled. 
					</div>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>