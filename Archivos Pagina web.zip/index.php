<?php
	session_start();
	require "conexion.php";
	require "funcs/funcs.php";

	$errors = array();

	if(!empty($_POST)){

		$nombre = $mysqli->real_escape_string($_POST['nombre']);
		$usuario = $mysqli->real_escape_string($_POST['usuario']);
		$password = $mysqli->real_escape_string($_POST['password']);

		if(isNullLogin($usuario, $password)){

			$errors[] = "Debe llenar todos los campos";
		}

		$errors[] = login($usuario, $password);
	}
?>
<!DOCTYPE HTML>
<html lang="en">
	<head>
		<title>Ingresar</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">

		<!-- Header -->
			<header id="header">
				<img src="images/logo.png" width="43" height="43" />  
				<a class="logo" href="welcome.php">TELEBIOM</a>
				<nav>
					<a href="#menu">Menu</a>
				</nav>
			</header>

		<!-- Nav -->
      <nav id="menu">
        <ul class="links">
        	<li class="nav-item"><a class="nav-link" href="telebiom.php">TELEBIOM</a></li>
          <li class="nav-item"><a class="nav-link active" href="principal.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="registro.php">Registro</a></li>
        </ul>
      </nav>

		<!-- Heading -->
			<div id="heading" >
				<h1>Ingresar</h1>
			</div>

		<!--=====================================
		CONTENIDO
		======================================-->
		<div class="inner">
			<div class="row gtr-uniform">
				<div class="col-lg-7">
                    <div class="p-5">
						<form id="loginform" class="form-horizontal" role="form" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" autocomplete="off">
							<div style="margin-bottom: 25px" class="input-group">
								<p><div class="col-8">
									<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
									<label for="email">Usuario o  Correo electrónico:</label>
									<input class="form-control" type="text" id="usuario" class="form-control" name="usuario" value="" placeholder="Usuario o email" required>
								</div></p>
							<div style="margin-bottom: 25px" class="input-group">
								<p><div class="col-8">
									<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
									<label for="pwd">Contraseña:</label>
									<input type="password" class="form-control" id="password" name="password" placeholder="Contraseña" required>
								</div></p>
								<div class="form-group">
		                            <div class="custom-control custom-checkbox small">
		                                <input type="checkbox" class="custom-control-input" id="customCheck">
		                                <label class="custom-control-label" for="customCheck">Recordar</label>
		                            </div>
		                        </div>
		                        <div class="text-center">
		                            <p><button type="submit" class="button primary">Ingresar</button></p>
		                        </div>
								<div class="text-center">
		                            <a class="small" href="forgot-password.html">¿Olvidó su contraseña?</a>
		                        </div>
		                       
							</div>
						</div>
						</form>
						<?php echo resultBlock($errors); ?>
					</div>
				</div>
				<div class="col-lg-7"><div class="p-5"></div></div>
				<div class="col-lg-7"><div class="p-5"></div></div>
				<div class="col-lg-7"><div class="p-5"></div></div>
				<div class="col-lg-7"><div class="p-5"></div></div>
				<div class="col-lg-7"><div class="p-5"></div></div>
				<div class="col-lg-7"><div class="p-5"></div></div>
				<div class="col-lg-7"><div class="p-5"></div></div>
				<div class="col-lg-7"><div class="p-5"></div></div>
				<div class="col-lg-7"><div class="p-5"></div></div>
				<div class="col-lg-7"><div class="p-5"></div></div>
				<div class="col-lg-7"><div class="p-5"></div></div>
				<div class="col-lg-7">
                    <div class="p-5">
                    	<p></p>
						<p><a href="principal.php" type="submit" class="button primary">Página principal</a></p>
					</div>
				</div>
			</div>
		</div>
		 
		<!-- Footer -->
		<footer id="footer">
			<div class="inner">
				<div class="content">
					<script src="https://kit.fontawesome.com/e7f1b73dfb.js" crossorigin="anonymous"></script>
					<section>
						<h4>Redes Sociales</h4>
						<ul class="icons">
							<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
							<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
							<li><a href="#" class="icon fa-linkedin"><span class="label">linkedIn</span></a></li>
							<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
						</ul>
					</section>
				</div>
				<div class="copyright">
					&copy; Untitled. 
				</div>
			</div>
		</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>