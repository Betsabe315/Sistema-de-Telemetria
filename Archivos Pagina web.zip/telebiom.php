<?php

	session_start();

?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Generic Page - Industrious by TEMPLATED</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link rel="stylesheet" href="assets/css/main.css" />
		
	</head>

	<body class="is-preload">

		<!-- Header -->
			<header id="header">
				<a class="logo" href="principal.php">TELEBIOM</a>
				<nav>
					<a href="#menu">Menu</a>
				</nav>
			</header>

		<!-- Nav -->
			<nav id="menu">
				<ul class="links">
					<li><a href="principal.php">Home</a></li>
					<li class="nav-item"><a class="nav-link" href="registro.php">Registro</a></li>
					<li class="nav-item"><a class="nav-link" href="index.php">Ingreso</a></li>
				</ul>
			</nav>

		<!-- Heading -->
			<div id="heading" >
				<h1> ¿Qué es TELEBIOM UNAM?</h1>
			</div>

		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="inner">
					<div class="content">
						<header>
							<h3><b>TELEBIOM UNAM</b></h3>
							<h4><b>Telemedicina Cardiológica</b></h4>
						</header>
						<p><b>TELEBIOM UNAM</b> es una página enfocada a la <i><b>telemedicina cardiológica</b></i>, cuya función es facilitar a los médicos una base de datos, en la cuál podrán encontrar los estudios de electrocardiograma (ECG) de sus pacientes, los cuales son obtenidos mediante una interfaz gráfica desarrollada por los mismos creadores de TELEBIOM.</p>
						<p>De manera que nuestro objetivo, no solo es proporcionar una base de datos para los médicos, sino también, facilitar a los pacientes la toma de dichos estudios, que en ocasiones por ubicación o costos es díficil de hacerlos y llevarlos al médico.</p>
						<dl>
							<dt>¿Qué es la <i>TELEMEDICINA</i>?</dt>
							<dd>
								<p>La Telemedicina, esta definida por la Organización Mundial de la Salud (OMS) como “la prestación de servicios de salud (en los que la distancia es un factor determinante) por parte de profesionales sanitarios a través de la utilización de tecnologías de la información y la comunicación (TICs) para el intercambio de información válida para el diagnóstico, el tratamiento, la prevención de enfermedades, la investigación y la evaluación y para la formación continuada de profesionales sanitarios, todo ello con el objetivo final de mejorar la salud de la población y de las comunidades”<a href="http://www.atryshealth.com/es/-qu%C3%A9-es-la-telemedicina-_1580">[1]</a>.</p>
								<p>Dentro de las ventajas que la telemedicina presenta, se encuentran las siguientes:</p> 
								<ul>
									<li>Obtener información en tiempo real.</li>
									<li>Dar un diagnóstico certero a distancia.</li>
									<li>Eficiencia operacional.</li>
									<li>Mejor rentabilidad.</li>
									<li>Mayor productividad.</li>
								</ul>
								<center><img src="images/logocom.jpeg" alt="Pic 02"width="40%" height="40%"></center>

							</dd>
						</dl>
					</div>
				</div>

		<div class="inner">
          	<div class="content">
          	<ul class="actions fit">
            	<li></li>
              	<li><a href="principal.php" class="button primary fit small">Página principal</a></li>
              	<li></li>
            </ul>
            <ul class="actions fit">
            	<li></li>
              	<li></li>
              	<li></li>
            </ul>
            <ul class="actions fit">
              	<li><a href="registro.php" class="button  fit small">Crea una cuenta</a></li>
              	<li></li>
              	<li><a href="index.php" class="button  fit small">¿Ya tienes cuenta? Ingresa</a></li>
            </ul>
          	</div>
        </div>
      </section>
				  
				
		<!-- Footer -->
		<footer id="footer">
				<div class="inner">
					<div class="content">
						<script src="https://kit.fontawesome.com/e7f1b73dfb.js" crossorigin="anonymous"></script>
						<section>
							<h4>Redes Sociales</h4>
							<ul class="icons">
								<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
								<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
								<li><a href="#" class="icon fa-linkedin"><span class="label">linkedIn</span></a></li>
								<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
							</ul>
						</section>
					</div>
					<div class="copyright">
						&copy; Untitled. 
					</div>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>