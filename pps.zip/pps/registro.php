<?php

	require 'conexion.php';
	require 'funcs/funcs.php';

	$errors = array();

	if(!empty($_POST))
	{
		$nombre = $mysqli->real_escape_string($_POST['nombre']);
		$usuario = $mysqli->real_escape_string($_POST['usuario']);
		$password = $mysqli->real_escape_string($_POST['password']);
		$con_password = $mysqli->real_escape_string($_POST['con_password']);
		$email = $mysqli->real_escape_string($_POST['email']);
		$captcha = $mysqli->real_escape_string($_POST['g-recaptcha-response']);

		$activo = 0;
		$tipo_usuario = 2;
		$secret = '6LeZhg4aAAAAAPBlSCDHBuhI1ezs9Qknigza5oFh';

		if(!$captcha){
			$errors[] = "Por favor verifica el captcha";
		}

		if(isNull($nombre, $usuario, $password, $con_password, $email)){
			$errors[] = "Debe llenar todos los campos";
		}

		if(!isEmail($email)){
			$errors[] = "Dirección de correo inválida";
		}

		if(!validaPassword($password, $con_password)){
			$errors[] = "Las contraseñas no coinciden";
		}

		if(usuarioExiste($usuario)){
			$errors[] = "El nombre de usuario $usuario ya existe";
		}

		if(emailExiste($email)){
			$errors[] = "El correo electrónico $email ya existe";
		}

		if(count($errors) == 0){

			$response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$captcha");

			$arr = json_decode($response, TRUE);

			if($arr['success']){

				$pass_hash = hashPassword($password);
				$token = generateToken();

				$registro = registraUsuario($usuario, $pass_hash, $nombre, $email, $activo, $token, $tipo_usuario);

				if($registro > 0){	

				#	$url = 'http://'.$_SERVER["SERVER_NAME"].'/login/activar.php?id='.$registro.'&val='.$token;

				#	$asunto = 'Activar Cuenta - Sistema de Usuarios';
				#	$cuerpo = "Estimado $nombre: <br /><br />Para continuar con el proceso de registro, es necesario que ingrese a la siguiente liga <a href='$url'>Activar cuenta</a>";

				#	if(enviarEmail($email, $nombre, $asunto, $cuerpo)){

				#		echo "Para terminar el proceso de registro siga las instrucciones que le hemos enviado a la dirección de correo electrónico: $email";

					echo '<div class="alert alert-success">El usuario ha sido registrado</div>';
					header ("Location:". "index.php");
					exit;

				#	}else{
				#		$errors[] = "Error al enviar email";
				#	}

				}else{
					$errors[] = "Error al registrar";
			}
				
			}else{
				$errors[] = 'Error al comprobar Captcha';
				
			}
		}
	}

	

?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Registro</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<script src="https://www.google.com/recaptcha/api.js"></script>
	</head>
	<body class="is-preload">

		<!-- Header -->
			<header id="header">
				<img src="images/logo.png" width="43" height="43" />  
				<a class="logo" href="welcome.php">TELEBIOM</a>
				<nav>
					<a href="#menu">Menu</a>
				</nav>
			</header>

		<!-- Nav -->
			<nav id="menu">
				<ul class="links">
					<li class="nav-item"><a class="nav-link" href="principal.php">Home</a></li>
					<li class="nav-item"><a class="nav-link active" href="telebiom.php">TELEBIOM</a></li>
					<li class="nav-item"><a class="nav-link" href="index.php">Ingresar</a></li>
				</ul>
			</nav>

		<!-- Heading -->
			<div id="heading" >
				<h1>Registro</h1>
			</div>

		<!--=====================================
		CONTENIDO
		======================================-->
		<div class="inner">
			<div class="row gtr-uniform">
				<div class="col-lg-7">
                    <div class="p-5">
                        <div class="text-center">
                            <h2 class="h4 text-gray-900 mb-4">Crear una cuenta</h2>
                        </div>
				
						<form method="POST" action="<?php $_SERVER['PHP_SELF'] ?>">
							<div class="container-fluid">
								<p><div class="col-8">
									<label for="nombre">Nombre:</label></div></p>
									<input type="text" class="form-control" placeholder="Nombre" id="nombre" name="nombre" value="<?php if(isset($nombre)) echo $nombre; ?>" required>
								</div>

								<div class="container-fluid">
								<p><div class="col-8">
									<label for="usuario">Usuario:</label></div></p>
									<input type="text" class="form-control" placeholder="Usuario" id="usuario" name="usuario" value="<?php if(isset($usuario)) echo $usuario; ?>" required>
								</div>

								<div class="container-fluid">
									<p><div class="col-8">		
										<label for="password">Contraseña:</label></div></p>
										<input type="password" class="form-control" placeholder="Contraseña" id="password" name="password" required>
								</div>

								<div class="container-fluid">
									<p><div class="col-8">		
										<label for="password">Confirmar contraseña:</label></div></p>
										<input type="password" class="form-control" placeholder="Confirmar Contraseña" id="con_password" name="con_password" required>
								</div>

								<div class="container-fluid">
									<p><div class="col-8">		
										<label for="email">Correo electrónico:</label></div></p>
										<input type="email" class="form-control" placeholder="Correo electrónico" id="email" name="email" value="<?php if(isset($email)) echo $email; ?>" required>
								</div>

								<div class="form-group">
									<p><div class="col-8">		
										<label for="captcha"></label></div></p>
										<div class="g-recaptcha col-lg-8" data-sitekey="6LeZhg4aAAAAACMbe7lN6M7wKS3BRRfsL6odOc1U"></div>
								</div>

								<p></p>	
		                        <div class="text-center">
		                            <p><button type="submit" class="button primary">Registar</button></p>
		                        </div>
								<div class="text-center">
		                            <a class="small" href="forgot-password.html">Olvidó su contraseña?</a>
		                        </div>
		                        <div class="text-center">
		                            <a class="small" href="ingreso.html">Ya tiene cuenta? Ingresar</a>
		                        </div>
						</form>
						<?php echo resultBlock($errors); ?>
					</div>
				</div>
			</div>
    	</div>

		<!-- Footer -->
			<footer id="footer">
				<div class="inner">
					<div class="content">
						<script src="https://kit.fontawesome.com/e7f1b73dfb.js" crossorigin="anonymous"></script>
						<section>
							<h4>Redes Sociales</h4>
							<ul class="icons">
								<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
								<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
								<li><a href="#" class="icon fa-linkedin"><span class="label">linkedIn</span></a></li>
								<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
							</ul>
						</section>
					</div>
					<div class="copyright">
						&copy; Untitled. 
					</div>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>