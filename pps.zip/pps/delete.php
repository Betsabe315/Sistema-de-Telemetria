<?php
session_start();
require_once "config.php";
require 'conexion.php';

  if(!isset($_SESSION["id_usuario"])){
    header("Location: index.php");
  }

  $idUsuario = $_SESSION['id_usuario'];
  $tipo_usuario = $_SESSION['tipo_usuario'];

  if($tipo_usuario == 1){
    $where = "";
    } else if($tipo_usuario == 2){
      $where = "WHERE id=$idUsuario";
  }

  $sql = "SELECT * FROM usuarios $where";
  $resultado = $mysqli->query($sql);

//unlink($_GET["name"]);
//$archivo = $_GET["name"];
//$tabla = "usuarios";

//$del = substr($archivo, 7);
//echo $del;
$stmt = Conexion::conectar()->prepare("UPDATE `usuarios` SET `name`='',`description`='',`ruta`='', `mostrar`='' $where");
$stmt->execute();

// Redirigiendo hacia atrás
header("Location: " . $_SERVER["HTTP_REFERER"])
?>