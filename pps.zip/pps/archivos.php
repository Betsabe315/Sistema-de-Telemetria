<?php
session_start();
  require 'conexion.php';

  if(!isset($_SESSION["id_usuario"])){
    header("Location: index.php");
  }

  $idUsuario = $_SESSION['id_usuario'];
  $tipo_usuario = $_SESSION['tipo_usuario'];

  if($tipo_usuario == 1){
    $where = "";
    } else if($tipo_usuario == 2){
      $where = "WHERE id=$idUsuario";
  }

  $sql = "SELECT * FROM usuarios $where";
  $resultado = $mysqli->query($sql);
  $row = $resultado->fetch_assoc();
  //echo $row['activacion'];
  
?> 
<!DOCTYPE HTML>
<html>
  <head>
    <title>TELEBIOM</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <link rel="stylesheet" href="assets/css/main.css" />
    
  </head>

  <body class="is-preload">

    <!-- Header -->
      <header id="header">
        <img src="images/logo.png" width="43" height="43" />  
        <a class="logo" href="welcome.php">TELEBIOM</a>
        <nav>
          <a href="#menu">Menu</a>
        </nav>
      </header>

    <!-- Nav -->
      <nav id="menu">
        <ul class="links">
          <li class="nav-item"><a class="nav-link active" href="welcome.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="generic.php">Cuenta</a></li>
          <li class="nav-item"><a class="nav-link" href="salir.php">Salir</a></li>
        </ul>
      </nav>

    <!-- Heading -->
      <div id="heading" >
        <h1>SUBIR ARCHIVOS</h1>
      </div>

    <!-- Main -->
      <section id="main" class="wrapper">
        <div class="inner">
          <div class="content">
            <p>En este apartado podrás subir tus archivos , asímismo podrás agregar una descripción a los mismos para facilitar al médico.</p>
          </div>
        </div>
        <div class="inner">
          <div class="content">
            <header>
              <h2>Subir archivos</h2>
            </header>

            <div class="inner">
              <div class="content">
                <form action="submit.php" method="post" enctype="multipart/form-data">
                Archivo: <br><br> 
                <input name="fichero" type="file" size="150" maxlength="150">  
                <br><br> Nombre: <input name="nombre" type="text" placeholder="Coloque el nombre del archivo" size="70" maxlength="70"> 
                <br><br> Descripcion: <textarea name="description" type="text" placeholder="Coloque la descripción del archivo" rows="6"></textarea>
                <br><br> 
                <input class="button primary" name="submit" type="submit" href="submit.php" value="Subir Archivo">   
                </form>
              </div>
            </div>
                
       
      </section>
    <!-- Footer -->
    <footer id="footer">
        <div class="inner">
          <div class="content">
            <script src="https://kit.fontawesome.com/e7f1b73dfb.js" crossorigin="anonymous"></script>
            <section>
              <h4>Redes Sociales</h4>
              <ul class="icons">
                <li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
                <li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
                <li><a href="#" class="icon fa-linkedin"><span class="label">linkedIn</span></a></li>
                <li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
              </ul>
            </section>
          </div>
          <div class="copyright">
            &copy; Untitled. 
          </div>
        </div>
      </footer>

    <!-- Scripts -->
      <script src="assets/js/jquery.min.js"></script>
      <script src="assets/js/browser.min.js"></script>
      <script src="assets/js/breakpoints.min.js"></script>
      <script src="assets/js/util.js"></script>
      <script src="assets/js/main.js"></script>

  </body>
</html>