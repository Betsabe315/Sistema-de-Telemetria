<?php 

	$mysqli = new mysqli("localhost", "root", "", "login")
#class Conexion{

#	static public function conectar(){

		#PDO("nombre del servidor; nombre de la base de datos", "usuario", "contraseña")

#		$link = new PDO("mysql:host=localhost;dbname=telemetria", 
#			            "root", 
#			            "");

#		$link->exec("set names utf8");

#		return $link;

#	}

#}
?>
