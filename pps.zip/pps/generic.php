<?php

	session_start();
	require 'conexion.php';

	if(!isset($_SESSION["id_usuario"])){
		header("Location: index.php");
	}

	$idUsuario = $_SESSION['id_usuario'];
	$tipo_usuario = $_SESSION['tipo_usuario'];

	if($tipo_usuario == 1){
		$where = "";
		} else if($tipo_usuario == 2){
			$where = "WHERE id=$idUsuario";
	}

	$sql = "SELECT * FROM usuarios $where";
	$resultado = $mysqli->query($sql);


?>

<!DOCTYPE HTML>
<html>
	<head>
    <title>TELEBIOM</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <link rel="stylesheet" href="assets/css/main.css" />
    
  </head>

  <body class="is-preload">

    <!-- Header -->
      <header id="header">
        <img src="images/logo.png" width="43" height="43" />  
        <a class="logo" href="welcome.php">TELEBIOM</a>
        <nav>
          <a href="#menu">Menu</a>
        </nav>
      </header>

    <!-- Nav -->
      <nav id="menu">
        <ul class="links">
          <li class="nav-item"><a class="nav-link active" href="welcome.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="generic.php">Cuenta</a></li>
          <li class="nav-item"><a class="nav-link" href="salir.php">Salir</a></li>
        </ul>
      </nav>

		<!-- Heading -->
			<div id="heading" >
				<h1>Cuenta personal</h1>
			</div>

		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="inner">
					<div class="content">
						<p>Aquí podrás encontrar la infromación general de tu cuenta</p>
					</div>
				</div>
				<div class="inner">
					<div class="content">
						<header>
							<h2>Subir archivos</h2>
						</header>
				<!-- Elements -->
				<div class="row">
					<div class="col-10 col-12-medium">
					<!-- Table -->
						<div class="table-wrapper">
							<table>
								<thead>
									<?php while($row = $resultado->fetch_assoc()) { ?>

										<tr>
											<th><i>Usuario</i></th>
											<th><i>Nombre</i></th>
											<th><i>Correo electrónico</i></th>
											<?php if($row['mostrar']==0){?>
												<th><i>Archivos</i></th>
												<th><i>Subir archivo</i></th>
											<?php }else{?>
												<th><i>Archivos disonibles</i></th>
											<?php } ?>
										</tr>
								</thead>
								<tbody>

										<tr>
											<td><?php echo $row['usuario']; ?></td>
											<td><?php echo $row['nombre']; ?></td>
											<td><?php echo $row['correo']; ?></td>
											<?php if($row['mostrar']==0){?>
												<td><?php echo "No hay archivos disponibles"; ?></td>
												<td><a href="archivos.php" style="color: red; font-size:18px;"><span class="icon fa-pencil" aria-hidden="true"></span> </a></td>
											<?php }else{?>
												<td><a href="archivero.php" class="button primary fit small">Ver archivos</a></td>					
											<?php } ?>
										</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
					</div>
				</div> 

		<div class="inner">
          	<div class="content">
          	<ul class="actions fit">
            	<li></li>
              	<li><a href="cuenta.php" class="button primary fit small">Configuración de la cuenta</a></li>
              	<li></li>
            </ul>
            <ul class="actions fit">
            	<li></li>
              	<li></li>
              	<li></li>
            </ul>
          	<ul class="actions fit">
            	<li></li>
              	<li><a href="welcome.php" class="button fit small">Página principal</a></li>
              	<li></li>
            </ul>
          	</div>
        </div>
      </section>
				  
				
		<!-- Footer -->
    <footer id="footer">
        <div class="inner">
          <div class="content">
            <script src="https://kit.fontawesome.com/e7f1b73dfb.js" crossorigin="anonymous"></script>
            <section>
              <h4>Redes Sociales</h4>
              <ul class="icons">
                <li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
                <li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
                <li><a href="#" class="icon fa-linkedin"><span class="label">linkedIn</span></a></li>
                <li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
              </ul>
            </section>
          </div>
          <div class="copyright">
            &copy; Untitled. 
          </div>
        </div>
      </footer>
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>