<?php
session_start();
  require 'conexion.php';

  if(!isset($_SESSION["id_usuario"])){
    header("Location: index.php");
  }

  $idUsuario = $_SESSION['id_usuario'];
  $tipo_usuario = $_SESSION['tipo_usuario'];

  if($tipo_usuario == 1){
    $where = "";
    } else if($tipo_usuario == 2){
      $where = "WHERE id=$idUsuario";
  }

  $sql = "SELECT * FROM usuarios $where";
  $resultado = $mysqli->query($sql);
  $row = $resultado->fetch_assoc();
  //echo $row['activacion'];

include 'config.php';
if (isset($_POST['submit'])) {   
    if(is_uploaded_file($_FILES['fichero']['tmp_name'])) { 
     
     
      // creamos las variables para subir a la db
        $ruta = "upload/"; 
        $nombrefinal= trim ($_FILES['fichero']['name']); //Eliminamos los espacios en blanco
        $nombrefinal= preg_replace("/\r/","", $nombrefinal);//Sustituye una expresión regular
        $upload= $ruta . $nombrefinal;  



        if(move_uploaded_file($_FILES['fichero']['tmp_name'], $upload)) { //movemos el archivo a su ubicacion 
                    
                   $nombre  = $_POST["nombre"]; 
                   $description  = $_POST["description"];
                   $muestra = 1; 


                   $query = "UPDATE `usuarios` SET `name`='$nombre',`description`='$description',`ruta`='.$nombrefinal.', `mostrar`='$muestra' $where";

       mysqli_query($mysqli,$query); 

       $sql = "SELECT * FROM usuarios";
       $resultado = $mysqli->query($sql);       
        }  
    }  
 } 
 ?>

 <!DOCTYPE HTML>
<html>
  <head>
    <title>TELEBIOM</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <link rel="stylesheet" href="assets/css/main.css" />
    
  </head>

  <body class="is-preload">

    <!-- Header -->
      <header id="header">
        <img src="images/logo.png" width="43" height="43" />  
        <a class="logo" href="welcome.php">TELEBIOM</a>
        <nav>
          <a href="#menu">Menu</a>
        </nav>
      </header>

    <!-- Nav -->
      <nav id="menu">
        <ul class="links">
          <li class="nav-item"><a class="nav-link active" href="welcome.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="generic.php">Cuenta</a></li>
          <li class="nav-item"><a class="nav-link" href="salir.php">Salir</a></li>
        </ul>
      </nav>

    <!-- Heading -->
      <div id="heading" >
        <h1>Carga completa</h1>
      </div>

    <!-- Main -->
      <section id="main" class="wrapper">
        <div class="inner">
          <div class="inner">
            <div class="inner">
              <div class="inner">
                <div class="inner">
                  <div class="inner">
                    <div class="inner">
                        <td><?php echo "<b>Upload exitoso!</b><br>"; ?></td>
                        <td><?php echo "<b>Datos:</b><br>"; ?></td>
                        <td><?php echo "Nombre: <i><a href=\"".$ruta . $nombrefinal."\">".$_FILES['fichero']['name']."</a></i><br>"; ?></td>  
                        <td><?php echo "Tipo MIME: <i>".$_FILES['fichero']['type']."</i><br>"; ?></td> 
                        <td><?php echo "Peso: <i>".$_FILES['fichero']['size']." bytes</i><br>"; ?></td>
                        <td><?php echo "<br><hr><br>"; ?></td>
              
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="inner">
          <div class="content">
            <ul class="actions fit">
              <li><a href="archivos.php" class="button primary fit">Regresar</a></li>
              <li></li>
              <li><a href="archivero.php" class="button primary fit">Ver Archivos</a></li>
            </ul>
            <ul class="actions fit"><li></li></ul>
            <ul class="actions fit"><li></li></ul>
            <ul class="actions fit">
              <li></li>
              <li><a href="welcome.php" class="button fit small">Página principal</a></li>
              <li></li>
            </ul>
          </div>
        </div>
      </section>

    <!-- Footer -->
    <footer id="footer">
      <div class="inner">
        <div class="content">
          <script src="https://kit.fontawesome.com/e7f1b73dfb.js" crossorigin="anonymous"></script>
          <section>
            <h4>Redes Sociales</h4>
            <ul class="icons">
              <li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
              <li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
              <li><a href="#" class="icon fa-linkedin"><span class="label">linkedIn</span></a></li>
              <li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
            </ul>
          </section>
        </div>
        <div class="copyright">
          &copy; Untitled. 
        </div>
      </div>
    </footer>

    <!-- Scripts -->
      <script src="assets/js/jquery.min.js"></script>
      <script src="assets/js/browser.min.js"></script>
      <script src="assets/js/breakpoints.min.js"></script>
      <script src="assets/js/util.js"></script>
      <script src="assets/js/main.js"></script>

  </body>
</html>