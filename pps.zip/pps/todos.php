<?php
	session_start();
	require 'conexion.php';
	require 'funcs/funcs.php';

	if(!isset($_SESSION["id_usuario"])){
		header("Location: index.php");
	}

	$idUsuario = $_SESSION['id_usuario'];
	$tipo_usuario = $_SESSION['tipo_usuario'];

	$sql = "SELECT id, nombre FROM usuarios WHERE id = '$idUsuario'";
	$result = $mysqli->query($sql);

	$row = $result->fetch_assoc();

?>

<!DOCTYPE HTML>
<html>
  <head>
		<title>TELEBIOM</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">

		<!-- Header -->
			<header id="header">
				<img src="images/logo.png" width="43" height="43" />  
				<a class="logo" href="welcome.php">TELEBIOM</a>
				<nav>
					<?php echo ($row['nombre']); ?>
					<a href="#menu">Menu</a>
				</nav>
			</header>

		<!-- Nav -->
			<nav id="menu">
				<ul class="links">
					<li class="nav-item"><a class="nav-link active" href="welcome.php">Home</a></li>
					<?php if($tipo_usuario == 1) { ; ?>
					<li class="nav-item"><a class="nav-link" href="todos.php">TODOS</a></li>
					<?php } ; ?>
					<li class="nav-item"><a class="nav-link" href="generic.php">Cuenta</a></li>
					<li class="nav-item"><a class="nav-link" href="salir.php">Salir</a></li>
					

				</ul>
			</nav>

    <!-- Heading -->
      <div id="heading" >
        <h1>TODOS LOS ARCHIVOS</h1>
      </div>

    <!-- Main -->
      <section id="main" class="wrapper">
        <!--tabla-->
        <div class="inner">
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title"><b>Descargas Disponibles</b></h3>
          </div>
          <div class="panel-body">
             
          <table class="table">
            <thead>
            <tr>
              <th width="7%"><i>#</i></th>
              <th width="70%"><i>Nombre del Archivo</i></th>
              <th width="13%"><i>Descargar</i></th>
              <th width="10%"><i>Eliminar</i></th>
            </tr>
            </thead>
              <tbody>
            <?php
            $archivos = scandir("upload");
            $num=0;
            for ($i=2; $i<count($archivos); $i++)
            {$num++;
            ?>
            <p>  
             </p>
                     
                <tr>
                  <th scope="row"><?php echo $num;?></th>
                  <td><?php echo $archivos[$i]; ?></td>
                  <td><a title="Descargar Archivo" href="upload/<?php echo $archivos[$i]; ?>" download="<?php echo $archivos[$i]; ?>" style="color: black; font-size:18px;"> <span class="icon fa-download" aria-hidden="true"></span> </a></td>
                  <td><a title="Eliminar Archivo" href="Eliminar.php?name=upload/<?php echo $archivos[$i]; ?>" style="color: red; font-size:18px;" onclick="return confirm('Esta seguro de eliminar el archivo?');"> <span class="icon fa-trash" aria-hidden="true"></span> </a></td>
                </tr>
              <?php }?> 

            </tbody>
          </table>
          </div>
        </div>
      <!-- Fin tabla--> 
        </div>
        </div>
      </section>
    <!-- Footer -->
    <footer id="footer">
      <div class="inner">
        <div class="content">
          <section>
            <h4>Redes Sociales</h4>
            <ul class="icons">
              <li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
              <li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
              <li><a href="#" class="icon fa-linkedin"><span class="label">linkedIn</span></a></li>
              <li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
            </ul>
          </section>
        </div>
        <div class="copyright">
          &copy; Untitled. 
        </div>
      </div>
    </footer>

    <!-- Scripts -->
      <script src="assets/js/jquery.min.js"></script>
      <script src="assets/js/browser.min.js"></script>
      <script src="assets/js/breakpoints.min.js"></script>
      <script src="assets/js/util.js"></script>
      <script src="assets/js/main.js"></script>

  </body>
</html>